import React, {Component} from 'react';

class PostContainer extends Component {
    render() {
        return (
            <div className="PostWrapper">
                {children}
            </Div>
        );
    };

export default PostContainer;
