import PostContainer from './PostContainer/PostContainer.js';

export {
    PostContainer
};
