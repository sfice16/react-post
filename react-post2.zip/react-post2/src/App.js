import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import {
  BrowserRouter as Router,
  Route,
} from 'react-router-dom';
import newPost from './components/Post/newPost';
import Post from './components/Post/Post';
import Main from './components/Main/Main';

const App = () => (
  <Router>
    <div>
      <Route exact path="/" component={Main} />
      <Route path="/newPost" component={newPost} />
      <Route path="/post/001" component={Post} />
    </div>
  </Router>
    );

export default App;
