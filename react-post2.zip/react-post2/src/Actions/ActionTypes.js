export const ADDPOST = 'ADDPOST';
export const DELETEPOST = 'DELETEPOST';
